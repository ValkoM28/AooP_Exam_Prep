﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Circle.ViewModels;

public class ViewModelBase : ObservableObject
{
}
